# 🛡️ PII Shield

**Local PII/PHI anonymizer — safely process sensitive documents with Claude.**

Strips Personally Identifiable Information (PII) and Protected Health Information (PHI) from documents before you paste them into Claude or any other LLM. Stores an encrypted local mapping so you can restore the originals later.

---

## What It Detects

| Category | Entities |
|---|---|
| **Identity** | Names, Dates of Birth, Passports, Driver's Licenses, SSN/ITIN |
| **Contact** | Email addresses, Phone numbers, Physical addresses |
| **Financial** | Credit card numbers, Bank account numbers, IBAN codes |
| **Medical** | Medical license numbers, NPI numbers |
| **Network** | IP addresses, URLs |
| **Org/Geo** | Organizations, Locations |

---

## Quick Start

### 1. Install (Mac / Linux)
```bash
chmod +x setup.sh
./setup.sh
source .venv/bin/activate
```

### 1. Install (Windows)
```
setup.bat
.venv\Scripts\activate.bat
```

### 2. Anonymize a document
```bash
python pii_shield.py anonymize patient_report.pdf
# → Creates patient_report_anonymized.txt
# → Prints a Session ID like: a3f8b21c
```

### 3. Paste the anonymized output into Claude
Open `patient_report_anonymized.txt` and paste its contents into Claude for analysis.

### 4. Restore originals if needed
```bash
python pii_shield.py restore patient_report_anonymized.txt --session a3f8b21c
```

---

## Commands

```
anonymize <file>             Strip PII from a document
  -o, --output <path>        Custom output path
  --threshold <0-1>          Detection confidence (default: 0.4)

restore [file] -s <session>  Put original values back
  -o, --output <path>        Write to file instead of printing

sessions                     List all stored sessions

inspect -s <session>         Show the full placeholder ↔ original mapping
```

---

## Supported File Types

| Format | Extension |
|---|---|
| PDF | `.pdf` |
| Word | `.docx`, `.doc` |
| Excel | `.xlsx`, `.xls`, `.xlsm` |
| CSV | `.csv` |
| Plain text | `.txt`, `.md` |

---

## How It Works

1. **Parse** — Extracts raw text from the document
2. **Analyze** — Microsoft Presidio + spaCy NLP scans for PII/PHI patterns
3. **Replace** — Each unique value gets a stable placeholder like `[PERSON_1]`, `[EMAIL_2]`
4. **Store** — The original↔placeholder mapping is saved to `~/.pii_shield/sessions/<id>.json`
5. **Output** — A clean `.txt` file with all sensitive data replaced

To restore, the tool reads the session file and swaps placeholders back.

---

## Sensitivity Tuning

The `--threshold` flag controls detection confidence (0 = catch everything, 1 = only certain matches):

```bash
# More aggressive — catch borderline cases (may have more false positives)
python pii_shield.py anonymize report.pdf --threshold 0.2

# Conservative — high-confidence matches only
python pii_shield.py anonymize report.pdf --threshold 0.7
```

Default is `0.4`, which works well for most business/medical documents.

---

## Session Storage

Sessions live in `~/.pii_shield/sessions/` as JSON files. They contain:
- The session ID and timestamp
- The source filename
- A mapping of every placeholder to its original value

**Keep your session IDs** if you need to restore originals. You can always run `python pii_shield.py sessions` to list them.

---

## Privacy Notes

- ✅ Everything runs **100% locally** — no data leaves your machine
- ✅ No telemetry or cloud calls
- ✅ Session files are stored in your home directory only
- ⚠️ The mapping files contain the **original sensitive values** — protect `~/.pii_shield/` accordingly
- ⚠️ NLP-based detection is not 100% perfect — always review the output before sending

---

## Dependencies

- [Microsoft Presidio](https://microsoft.github.io/presidio/) — PII detection & anonymization engine
- [spaCy](https://spacy.io/) — NLP backbone for named entity recognition
- [pdfplumber](https://github.com/jsvine/pdfplumber) — PDF text extraction
- [python-docx](https://python-docx.readthedocs.io/) — Word document parsing
- [pandas](https://pandas.pydata.org/) + [openpyxl](https://openpyxl.readthedocs.io/) — Excel/CSV parsing
